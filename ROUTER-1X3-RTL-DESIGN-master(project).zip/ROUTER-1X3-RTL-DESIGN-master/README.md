# ROUTER-1X3-RTL-DESIGN
Architectural design of data router in verilog
